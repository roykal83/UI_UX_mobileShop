export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAtFwpg_RA5-4XeHspRRxsT9zcPP8rMz7I",
    authDomain: "mobileshop-e8695.firebaseapp.com",
    databaseURL: "https://mobileshop-e8695.firebaseio.com",
    projectId: "mobileshop-e8695",
    storageBucket: "mobileshop-e8695.appspot.com",
    messagingSenderId: "588442599758"
  }
};
