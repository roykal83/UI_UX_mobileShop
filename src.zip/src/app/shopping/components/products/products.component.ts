import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../../../shared/models/product';
import { ShoppingCartService } from '../../../shared/services/shopping-cart.service';
import { Subscription } from 'rxjs/Subscription';
import { ShoppingCart } from '../../../shared/models/shopping-cart';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})

export class ProductsComponent implements OnInit{
  products: Product[] = [];
  filteredProducts: Product[] = [];
  category: string;
  cart$: Observable<ShoppingCart>;
  minPrice: number = 0;
  maxPrice: number = 0;

  constructor (
    private route: ActivatedRoute,
    private productService: ProductService,
    private shoppingCartService: ShoppingCartService
    ) { 
  }

  async ngOnInit(){
    this.cart$ = await this.shoppingCartService.getCart();
    this.populateProducts();   
  }

  private populateProducts(){
    this.productService
    .getAll()
    .switchMap(products => {
      this.products = products; 
      return this.route.queryParamMap;
    })
    .subscribe(params => {
      this.category = params.get('category');
      this.minPrice = Number(params.get('minprice'));
      this.maxPrice = Number(params.get('maxprice'));
      if (this.maxPrice === 0)
        this.maxPrice = 1111111111;

      console.log("This min price is :" +this.minPrice);
      console.log("This max price is :" +this.maxPrice);
      this.applyFilter();
    }); 
  }

  private applyFilter(){
    if (this.minPrice && this.maxPrice){
      this.filteredProducts = (this.maxPrice && this.minPrice) ?
      this.products.filter(p => 
        (Number(p.price) >= this.minPrice && Number(p.price) <= this.maxPrice)
      ):
      this.products; 
    }
    else{
      this.filteredProducts = (this.category) ?
      this.products.filter(p => p.category === this.category):
      this.products; 
    }   
  }
}